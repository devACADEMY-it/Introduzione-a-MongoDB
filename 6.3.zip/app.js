const Express = require('express');
const BodyParser = require('body-parser');
const Mongoose = require('mongoose');

var app = Express();
app.use(BodyParser.json());
app.use(BodyParser.urlencoded({ extended: true }));

Mongoose.connect("mongodb://localhost:27017/myApp", { useNewUrlParser: true, useUnifiedTopology: true });

const schema = new Mongoose.Schema({
  title: String,
  author: String,
  content: String,
  date: { type: Date, default: Date.now },
  hidden: { type: Boolean, required: true },
  comments: [{ content: String, date: Date }],
  meta: {
    likes: Number,
    favs: Number
  }
});
const Article = Mongoose.model('Article', schema, 'articles');

// localhost:3000/articles
app.get('/articles', async (request, response, next) => {
  try {
    const result = await Article.find().exec();
    response.send(result);
  } catch (error) {
    response.status(500).send(error);
  }
});

// localhost:3000/articles
app.post('/articles', async (request, response, next) => {
  try {
    const newDocument = new Article(request.body);
    const result = await newDocument.save();
    response.send(result);
  } catch (error) {
    response.status(500).send(error);
  }
});

app.listen(3000, () => {
  console.log('Listening on port 3000');
});
