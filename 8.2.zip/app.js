const Mongoose = require('mongoose');

Mongoose.connect("mongodb://localhost:27017/myApp", {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const schema = Mongoose.Schema({
  name: { type: String, required: true },
  surname: { type: String, required: true },
  phone: {
    type: String,
    validate: {
      validator: function(v) {
        return /\d{3}-\d{4}-\d{2}/.test(v)
      },
      message: (props) => `${props.value} non è un numero di telefono valido!`
    },
    required: true
  },
  gender: { type: String, enum: ['M', 'F'], required: false, default: 'M' },
  city: { type: String, enum: ['Roma', 'Milano', 'Napoli'], required: true }
});

const User = Mongoose.model('User', schema, 'users');

// 555-012-012 NON VALIDO
// 555 0120 12 NON VALIDO
// 555-0120-12 VALIDO       REGEX:
// 555-012-012 NON VALIDO

let error;
const newUser = new User({
  name: 'Adriano',
  surname: 'Grimaldi',
  phone: '555-0120-12',
  city: 'Napoli'
});
error = newUser.validateSync();
console.log(newUser);
console.log(error);

