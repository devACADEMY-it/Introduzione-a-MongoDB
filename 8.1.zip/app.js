const Mongoose = require('mongoose');

Mongoose.connect("mongodb://localhost:27017/myApp", {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const schema = Mongoose.Schema({
  eggs: {
    type: Number,
    min: [2, 'Così poche uova?'],
    max: 6
  },
  bacon: {
    type: Number,
    required: [true, "Perchè non vuoi metterci un po' di bacon?"]
  },
  drink: {
    type: String,
    enum: ['Te', 'Caffè'],
    required: function() {
      return this.bacon > 3;
    }
  }
});

const Order = Mongoose.model('Order', schema, 'orders');

const orderOne = new Order({
  eggs: 2,
  bacon: 3,
  drink: 'Caffè'
});
console.log(orderOne);
