const Express = require('express');
const BodyParser = require('body-parser');
const Mongoose = require('mongoose');

var app = Express();

Mongoose.connect("mongodb://localhost:27017/myApp", { useNewUrlParser: true, useUnifiedTopology: true });

const schema = new Mongoose.Schema({
  title: String,
  author: String,
  content: String,
  date: { type: Date, default: Date.now },
  hidden: { type: Boolean, default: false },
  comments: [{ content: String, date: Date }],
  meta: {
    likes: Number,
    favs: Number
  }
});

const Article = Mongoose.model('Article', schema, 'articles');

const first = new Article({
  title: 'Articolo bellissimo',
  author: 'Adriano',
  content: 'Contenuto dell\'articolo',
  meta: {
    likes: 0,
    favs: 0
  }
});
console.log(JSON.parse(JSON.stringify(first)));
first.save();
