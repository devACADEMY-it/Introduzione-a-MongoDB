const Mongoose = require('mongoose');

Mongoose.connect("mongodb://localhost:27017/myApp", {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const schema = Mongoose.Schema({
  eggs: {
    type: Number
  },
  bacon: {
    type: Number
  },
  drink: {
    type: String,
    enum: ['Te', 'Caffè']
  }
});

const Order = Mongoose.model('Order', schema, 'orders');

const orderOne = new Order({
  eggs: 2,
  bacon: 3,
  drink: 'Caffè'
});
orderOne.save();
