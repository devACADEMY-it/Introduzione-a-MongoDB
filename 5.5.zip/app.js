const Express = require('express');
const BodyParser = require('body-parser');
const Mongoose = require('mongoose');

var app = Express();

Mongoose.connect("mongodb://localhost:27017/restDB", { useNewUrlParser: true, useUnifiedTopology: true });

const schema = new Mongoose.Schema({
  title: String,
  author: String,
  content: String,
  date: { type: Date, default: Date.now },
  hidden: Boolean,
  comments: [{ content: String, date: Date }],
  meta: {
    likes: Number,
    favs: Number
  }
});

const Article = Mongoose.model('Article', schema);

const first = new Article();
console.log(JSON.parse(JSON.stringify(first)));
