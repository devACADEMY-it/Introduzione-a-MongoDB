const Mongoose = require('mongoose');

Mongoose.connect("mongodb://localhost:27017/myApp", {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const schema = Mongoose.Schema({
  name: { type: String, required: true },
  surname: { type: String, required: true },
  phone: {
    type: String,
    validate: {
      validator: function(v) {
        return /\d{3}-\d{4}-\d{2}/.test(v)
      },
      message: (props) => `${props.value} non è un numero di telefono valido!`
    },
    required: true
  },
  gender: { type: String, enum: ['M', 'F'], required: false, default: 'M' },
  city: { type: String, enum: ['Roma', 'Milano', 'Napoli'], required: true }
});

const User = Mongoose.model('User', schema, 'users');

/*
User.find({}, function (error, result) {
  console.log(result);
}).sort({ name: 1 }).limit(4).select({ name: 1, surname: 1 });
 */

async function getUserByCity () {
  const result = await User.aggregate([ { $match: { city: 'Milano' } } ]);
  console.log(result);
}
getUserByCity();
