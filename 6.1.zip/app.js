const Express = require('express');
const BodyParser = require('body-parser');
const Mongoose = require('mongoose');

var app = Express();
app.use(BodyParser.json());
app.use(BodyParser.urlencoded({ extended: true }));

Mongoose.connect("mongodb://localhost:27017/myApp", { useNewUrlParser: true, useUnifiedTopology: true });

const schema = new Mongoose.Schema({
  title: String,
  author: String,
  content: String,
  date: { type: Date, default: Date.now },
  hidden: { type: Boolean, default: false },
  comments: [{ content: String, date: Date }],
  meta: {
    likes: Number,
    favs: Number
  }
});

const Article = Mongoose.model('Article', schema, 'articles');

const first = new Article({
  title: 'Articolo bellissimo',
  author: 'Adriano',
  content: 'Contenuto dell\'articolo 1',
  meta: {
    likes: 2,
    favs: 4
  }
});
const second = new Article({
  title: 'Articolo stupendo',
  author: 'Adriano',
  content: 'Contenuto dell\'articolo 2',
  meta: {
    likes: 9,
    favs: 2
  }
});

// localhost:3000/articles
app.get('/articles', async (request, response, next) => {
  try {
    const result = await Article.find().exec();
    response.send(result);
  } catch (error) {
    response.status(500).send(error);
  }
});

app.listen(3000, () => {
  console.log('Listening on port 3000');
});
