const Express = require('express');
const BodyParser = require('body-parser');
const Mongoose = require('mongoose');

var app = Express();
app.use(BodyParser.json());
app.use(BodyParser.urlencoded({ extended: true }));

Mongoose.connect("mongodb://localhost:27017/myApp", { useNewUrlParser: true, useUnifiedTopology: true });

const schema = new Mongoose.Schema({
  title: String,
  author: String,
  content: String,
  date: { type: Date, default: Date.now },
  hidden: { type: Boolean, required: true },
  comments: [{ content: String, date: Date }],
  meta: {
    likes: Number,
    favs: Number
  }
});
const Article = Mongoose.model('Article', schema, 'articles');

// GET localhost:3000/articles
app.get('/articles', async (request, response, next) => {
  try {
    const result = await Article.find().exec();
    response.send(result);
  } catch (error) {
    response.status(500).send(error);
  }
});

// POST localhost:3000/articles
app.post('/articles', async (request, response, next) => {
  try {
    const newDocument = new Article(request.body);
    const result = await newDocument.save();
    response.send(result);
  } catch (error) {
    response.status(500).send(error);
  }
});

// GET localhost:3000/articles/:id
app.get('/articles/:id', async (request, response, next) => {
  try {
    const result = await Article.findById(request.params.id).exec();
    response.send(result);
  } catch (error) {
    response.status(500).send(error);
  }
});

// PUT localhost:3000/articles/:id
app.put('/articles/:id', async (request, response, next) => {
  try {
    const article = await Article.findById(request.params.id).exec();
    article.set(request.body);
    const result = await article.save();
    response.send(result);
  } catch (error) {
    response.status(500).send(error);
  }
});

// DELETE localhost:3000/articles/:id
app.delete('/articles/:id', async (request, response, next) => {
  try {
    const result = await Article.deleteOne({ _id: request.params.id }).exec();
    response.send(result);
  } catch (error) {
    response.status(500).send(error);
  }
});

app.listen(3000, () => {
  console.log('Listening on port 3000');
});
